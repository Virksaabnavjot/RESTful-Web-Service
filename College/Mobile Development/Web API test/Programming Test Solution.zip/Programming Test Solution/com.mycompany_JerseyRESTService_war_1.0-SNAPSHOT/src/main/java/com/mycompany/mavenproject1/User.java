package com.mycompany.mavenproject1;

import java.util.Date;
import java.util.Map;

class User {

    private final Integer id;
    private final String name;
    private final String occupation;
    private final Date birthday;
    
    public User(Integer id, String name, String occupation, Date birthday){
         this.id = id;
         this.name = name;
         this.occupation = occupation;
         this.birthday = birthday;
    }

    Integer getID() {
        return id;
    }
    
}
