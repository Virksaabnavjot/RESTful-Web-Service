package com.mycompany.mavenproject1;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

/**
 * All paths specified in this class are prefixed by /users because of the path annotation at this level
 * @author dominiccarr
 */
@Path("/users")
public class UsersService {

    /**
     * this method responds to a GET request for the resource located at '/users'
     * 
     * @return A HTTP Response object which has as it's entity a JSON representation of the resource
     * INVOKE via curl -vi -X GET http://localhost:8080/api/users
     */
    @GET
    public Response getUsers() {
        // retreieve a List of User objects
        List<User> list = getUserList();
        // instantiante a Gson object
        Gson g = new GsonBuilder().setPrettyPrinting().create();
        // convert the list to a JSON representation
        String message = g.toJson(list);
        // return a response with the HTTP status 200, and the entity included
        return Response.status(200).entity(message).build();
    }

    /**
     * Returns a map of Users
     * @return a map of users
     */
    private Map<Integer, User> getUserMap() {
        Map<Integer, User> map = new HashMap<>();
        // the key is the id and the value is the User Object
        map.put(1, new User(1, "Dominic", "lecturer", new Date()));
        map.put(2, new User(2, "John", "Politican", new Date()));
        map.put(3, new User(3, "Philip", "Job Seeker", new Date()));

        return map;
    }

    /**
     * Returns a list of Users
     * @return a list of users
     */
    private List<User> getUserList() {
        List<User> users = new ArrayList<>();

        users.add(new User(1, "Dominic", "lecturer", new Date()));
        users.add(new User(2, "John", "Criminal Mastermind", new Date()));
        users.add(new User(3, "Philip", "Job Seeker", new Date()));

        return users;
    }

    /** 
     * responds to a delete request
     * @param id the id of the use
     * @return a response indicating what happened with the request, was the user found and deleted?
     * INVOKE  curl -vi -X DELETE http://localhost:8080/api/users/12
     */
    @DELETE
    @Path("/{id}")
    public Response deleteUser(@PathParam("id") Integer id) {
        // this method could be extended to actually check if the user is in the list and return a sensible error cod eif the user is not found
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("request_status", "true");
        Gson g = new Gson();
        String message = g.toJson(errorMap);
        return Response.status(200).entity(message).build();
    }

    /** 
     * Responds to a GET request for a specific user e.g. /users/12
     * @param id the id of the user
     * @return 
     * INVOKE curl -vi -X GET http://localhost:8080/api/users/2 get a 200 response
     * INVOKE curl -vi -X GET http://localhost:8080/api/users/12 get a 404
     */
    @GET
    @Path("/{id}")
    public Response getUser(@PathParam("id") Integer id) {
        Map<Integer, User> map = getUserMap();
        // can retreive the user from the map using the id as the key.
        User target = map.get(id);

        // if the user does not exist
        if (target == null) {
            Map<String, String> errorMap = new HashMap<>();
            errorMap.put("request_status", "failed");
            Gson g = new Gson();
            String message = g.toJson(errorMap);
            // return a 404
            return Response.status(404).entity(message).build();
        }

        // otherwise we convert and return the user we have searched for
        Gson g = new Gson();
        String message = g.toJson(target);

        return Response.status(200).entity(message).build();
    }

    /**
     * Handles a post request
     * @param requestBody JSON String which is converted to a Java Object of type User
     * @return 
     * INVOKE curl -vi -X POST http://localhost:8080/api/users/ -d "{"id":2,"name":"John","occupation":"Politican"}"
     **/
    @POST
    public Response handlePost(String requestBody) {
        System.out.println(requestBody);
        User u = addUserToDatabase(requestBody);

        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("status", "success");
        jsonMap.put("resource-uri", "/users/"+u.getID()); // assume 12 is the ID of the user we pretended to create
        Gson gson = new Gson();

        return Response.status(200).entity(gson.toJson(jsonMap)).build();
    }

    private User addUserToDatabase(String requestBody) {
        Gson gson = new Gson();

        User u = gson.fromJson(requestBody, User.class);
        return u; // lie and say we added the user to the database
    }

}