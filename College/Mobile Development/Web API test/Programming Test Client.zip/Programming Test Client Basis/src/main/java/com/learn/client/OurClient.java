package com.learn.client;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class OurClient {
    
    private final String host;
    private final int port;
    private final String basePath;
    
    public static void main(String[] args) {
        OurClient client = new OurClient("localhost", 8080, "/api/users");
        System.out.println("Get all users response".toUpperCase());
        client.getUsers();
        System.out.println("Get an individual user response".toUpperCase());
        client.getUser(1);
        System.out.println("Delete user 1 response".toUpperCase());
        client.deleteUser(1);
        System.out.println("post a new user response".toUpperCase());
        client.post();
    }
    
    public String getURL(){
        return "http://localhost:" + port + "/api/users";
    }

    
    public OurClient(String host, int port, String basePath){
        this.host = host;
        this.port = port;
        this.basePath =basePath;
    }
    
    public void getUsers(){
        String getUrl = getURL();
        
        Client client = Client.create();
        WebResource target = client.resource(getUrl);

        ClientResponse response = target.get(ClientResponse.class);
        
        System.out.println(response.getEntity(String.class));
    }
    
    public void getUser(Integer id){
        String getUrl = getURL()+"/"+id;
        
        Client client = Client.create();
        WebResource target = client.resource(getUrl);

        ClientResponse response = target.get(ClientResponse.class);
        
        System.out.println(response.getEntity(String.class));
    }
    
    public void deleteUser(Integer id){
        String getUrl = getURL()+"/"+id;
        
        Client client = Client.create();
        WebResource target = client.resource(getUrl);

        ClientResponse response = target.delete(ClientResponse.class);
        
        System.out.println(response.getEntity(String.class));
    }

    private void post() {
        String getUrl = getURL();
        
        Client client = Client.create();
        WebResource target = client.resource(getUrl);
        String input = "{\"id\":2,\"name\":\"John\",\"occupation\":\"Politican\"}";

        ClientResponse response = target.post(ClientResponse.class, input);
        
        System.out.println(response.getEntity(String.class));
    }
}